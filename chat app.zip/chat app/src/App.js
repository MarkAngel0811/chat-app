import React from 'react';

import ChatShell from './containers/shell/ChatShell';

const App = () => {
  return (
    <ChatShell />
  );
}

export default App;
